package com.jobboard.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jobboard.model.Job;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriUtils;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class JobProviderService {

    @Value("${adzuna.app.id}")
    private String ADZUNA_APP_ID;

    @Value("${adzuna.app.key}")
    private String ADZUNA_APP_KEY;

    @Value("${usajobs.useragent}")
    private String USAJOBS_USER_AGENT;

    @Value("${usajobs.authkey}")
    private String USAJOBS_AUTH_KEY;

    private final ObjectMapper mapper = new ObjectMapper();

    public List<Job> aggregateJobs(String keyword, String location) {
        List<Job> all = new ArrayList<>();
        all.addAll(fetchRemoteOK(keyword));
        all.addAll(fetchAdzuna(keyword, location));
        all.addAll(fetchUsaJobs(keyword, location));
        return all;
    }

    // RemoteOK (public JSON)
    public List<Job> fetchRemoteOK(String keyword) {
        List<Job> list = new ArrayList<>();
        try {
            String urlS = "https://remoteok.com/api";
            URL url = new URL(urlS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            conn.setRequestMethod("GET");
            try (InputStream is = conn.getInputStream()) {
                JsonNode root = mapper.readTree(is);
                if (root.isArray()) {
                    for (JsonNode n : root) {
                        if (n.has("position") && n.has("company")) {
                            String pos = n.path("position").asText("");
                            String comp = n.path("company").asText("");
                            String loc = n.path("location").asText("Remote");
                            String link = n.path("url").asText("");
                            if (pos.toLowerCase().contains(keyword.toLowerCase()) ||
                                comp.toLowerCase().contains(keyword.toLowerCase())) {
                                list.add(new Job(pos, comp, loc, link, "remoteok"));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Adzuna
    public List<Job> fetchAdzuna(String keyword, String location) {
        List<Job> list = new ArrayList<>();
        try {
            if (ADZUNA_APP_ID == null || ADZUNA_APP_ID.isBlank()) return list;
            String kw = UriUtils.encodeQueryParam(keyword, StandardCharsets.UTF_8);
            String loc = UriUtils.encodeQueryParam(location, StandardCharsets.UTF_8);
            String urlS = String.format("https://api.adzuna.com/v1/api/jobs/us/search/1?app_id=%s&app_key=%s&results_per_page=20&what=%s&where=%s",
                    ADZUNA_APP_ID, ADZUNA_APP_KEY, kw, loc);
            URL url = new URL(urlS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            try (InputStream is = conn.getInputStream()) {
                JsonNode root = mapper.readTree(is);
                JsonNode results = root.path("results");
                if (results.isArray()) {
                    for (JsonNode r : results) {
                        String title = r.path("title").asText("");
                        String company = r.path("company").path("display_name").asText("");
                        String locStr = r.path("location").path("display_name").asText("");
                        String link = r.path("redirect_url").asText("");
                        list.add(new Job(title, company, locStr, link, "adzuna"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // USAJobs
    public List<Job> fetchUsaJobs(String keyword, String location) {
        List<Job> list = new ArrayList<>();
        try {
            if (USAJOBS_USER_AGENT == null || USAJOBS_USER_AGENT.isBlank()) return list;
            String kw = UriUtils.encodeQueryParam(keyword, StandardCharsets.UTF_8);
            String loc = UriUtils.encodeQueryParam(location, StandardCharsets.UTF_8);
            String urlS = String.format("https://data.usajobs.gov/api/search?Keyword=%s&LocationName=%s", kw, loc);
            URL url = new URL(urlS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USAJOBS_USER_AGENT);
            conn.setRequestProperty("Authorization-Key", USAJOBS_AUTH_KEY);
            try (InputStream is = conn.getInputStream()) {
                JsonNode root = mapper.readTree(is);
                JsonNode items = root.path("SearchResult").path("SearchResultItems");
                if (items.isArray()) {
                    for (JsonNode item : items) {
                        JsonNode desc = item.path("MatchedObjectDescriptor");
                        String title = desc.path("PositionTitle").asText("");
                        String company = desc.path("OrganizationName").asText("");
                        String locStr = desc.path("PositionLocationDisplay").asText("");
                        String link = desc.path("PositionURI").asText("");
                        list.add(new Job(title, company, locStr, link, "usajobs"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
