package com.jobboard.service;


import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.jobboard.model.Job;
import com.jobboard.model.SavedJob;
import com.jobboard.repository.SavedJobRepository;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SavedJobService {

    private final SavedJobRepository repo;

    public SavedJobService(SavedJobRepository repo) {
        this.repo = repo;
    }

    public SavedJob saveJob(Job job) {
        SavedJob s = new SavedJob(job.getTitle(), job.getCompany(), job.getLocation(), job.getLink(), job.getSource());
        return repo.save(s);
    }

    public List<SavedJob> listSaved(String company, String location, String source, Boolean applied) {
        Specification<SavedJob> spec = (root, query, cb) -> {
            Predicate p = cb.conjunction();
            if (company != null && !company.isBlank()) {
                p = cb.and(p, cb.like(cb.lower(root.get("company")), "%" + company.toLowerCase() + "%"));
            }
            if (location != null && !location.isBlank()) {
                p = cb.and(p, cb.like(cb.lower(root.get("location")), "%" + location.toLowerCase() + "%"));
            }
            if (source != null && !source.isBlank()) {
                p = cb.and(p, cb.equal(root.get("source"), source));
            }
            if (applied != null) {
                p = cb.and(p, cb.equal(root.get("applied"), applied));
            }
            return p;
        };
        return repo.findAll(spec);
    }

    public Optional<SavedJob> markApplied(Long id, String notes) {
        Optional<SavedJob> opt = repo.findById(id);
        if (opt.isPresent()) {
            SavedJob s = opt.get();
            s.setApplied(true);
            s.setAppliedAt(LocalDateTime.now());
            if (notes != null) s.setNotes(notes);
            repo.save(s);
        }
        return opt;
    }

    public ByteArrayInputStream exportAppliedCsv() {
        List<SavedJob> applied = repo.findAll((root, query, cb) -> cb.equal(root.get("applied"), true));
        StringBuilder sb = new StringBuilder();
        sb.append("id,title,company,location,source,appliedAt,link,notes\n");
        for (SavedJob s : applied) {
            sb.append(s.getId()).append(",");
            sb.append(escapeCsv(s.getTitle())).append(",");
            sb.append(escapeCsv(s.getCompany())).append(",");
            sb.append(escapeCsv(s.getLocation())).append(",");
            sb.append(escapeCsv(s.getSource())).append(",");
            sb.append(s.getAppliedAt() != null ? s.getAppliedAt().toString() : "").append(",");
            sb.append(escapeCsv(s.getLink())).append(",");
            sb.append(escapeCsv(s.getNotes())).append("\n");
        }
        return new ByteArrayInputStream(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    private String escapeCsv(String s) {
        if (s == null) return "";
        String out = s.replace("\"", "\"\"");
        if (out.contains(",") || out.contains("\"") || out.contains("\n")) {
            return "\"" + out + "\"";
        } else {
            return out;
        }
    }
}
