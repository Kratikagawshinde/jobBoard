package com.jobboard.controller;


import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;


import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jobboard.model.Job;
import com.jobboard.model.SavedJob;
import com.jobboard.service.JobProviderService;
import com.jobboard.service.SavedJobService;

@RestController
@RequestMapping("/api")
public class JobController {

    private final JobProviderService providerService;
    private final SavedJobService savedJobService;
//private static final String AUTH_KEY = "18cQjts18SRJaXydY/NTwh9WO7oLH82KbDVthVpkrEM="; // Your API Key
//private static final String USER_AGENT = "kratikagawshinde744@gmail.com"; // Your registered email

    public JobController(JobProviderService providerService, SavedJobService savedJobService) {
        this.providerService = providerService;
        this.savedJobService = savedJobService;
    }

    // Aggregate search from 3 providers
    @GetMapping("/search")
    public ResponseEntity<List<Job>> searchJobs(@RequestParam(defaultValue = "java") String keyword,
                                                @RequestParam(defaultValue = "") String location) {
        List<Job> list = providerService.aggregateJobs(keyword, location);
        return ResponseEntity.ok(list);
    }

    // Save a job (user likes it)
    @PostMapping("/save")
    public ResponseEntity<SavedJob> saveJob(@RequestBody Job job) {
        SavedJob saved = savedJobService.saveJob(job);
        return ResponseEntity.ok(saved);
    }

    // List saved with filters
    @GetMapping("/saved")
    public ResponseEntity<List<SavedJob>> listSaved(@RequestParam(required = false) String company,
                                                    @RequestParam(required = false) String location,
                                                    @RequestParam(required = false) String source,
                                                    @RequestParam(required = false) Boolean applied) {
        List<SavedJob> list = savedJobService.listSaved(company, location, source, applied);
        return ResponseEntity.ok(list);
    }

    // Mark saved job as applied
    @PostMapping("/saved/{id}/apply")
    public ResponseEntity<?> markApplied(@PathVariable Long id, @RequestParam(required = false) String notes) {
        Optional<SavedJob> opt = savedJobService.markApplied(id, notes);
        return opt.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Export applied jobs as CSV
    @GetMapping("/export/applied")
    public ResponseEntity<InputStreamResource> exportApplied() {
        ByteArrayInputStream in = savedJobService.exportAppliedCsv();
        InputStreamResource resource = new InputStreamResource(in);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=applied_jobs.csv")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(resource);
    }
}
